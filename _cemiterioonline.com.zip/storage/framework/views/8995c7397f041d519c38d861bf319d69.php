<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Relatório de Sepultamentos</title>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #000000; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        h1 { text-align: center; }
    </style>
</head>
<body>
    <h1>Relatório de Sepultamentos</h1>
    <h2><?php echo e(session('sepultamentos_empresa.nome') ?? 'Empresa não informada'); ?></h2>
    <table>
        <thead>
            <tr>
                <th>Nome do Falecido</th>
                
                <th>Quadra</th>
                <th>Fila</th>
                <th>Cova</th>
                <th>OS</th>
                <th>Data de Falecimento</th>
                
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = session('sepultamentos_pdf_data', []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sepultamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sepultamento['nome_falecido']); ?></td>
                   
                    <td><?php echo e($sepultamento['quadra']); ?></td>
                    <td><?php echo e($sepultamento['fila']); ?></td>
                    <td><?php echo e($sepultamento['cova']); ?></td>
                    <td><?php echo e($sepultamento['ordem_sepultamento']); ?></td>
                    <td><?php echo e($sepultamento['data_falecimento']); ?></td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="total">
        Total de registros: <?php echo e(count(session('sepultamentos_pdf_data', []))); ?>

    </div>
</body>
</html><?php /**PATH /home/u566381090/domains/cemiterioonline.com/resources/views/pdf/sepultamentos.blade.php ENDPATH**/ ?>