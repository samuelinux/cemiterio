<?php $__env->startSection('title', 'Editar Usuário'); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-2xl font-bold text-gray-900">Editar Usuário</h2>
        <a href="<?php echo e(route('admin.users.index')); ?>"
           class="px-3 py-2 rounded-md text-sm bg-gray-100 hover:bg-gray-200 text-gray-800">
           Voltar
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.user-form-edit', ['userId' => $user->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3658694338-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.user-permissions-form', ['userId' => $user->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3658694338-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u566381090/domains/cemiterioonline.com/resources/views/admin/users/edit.blade.php ENDPATH**/ ?>