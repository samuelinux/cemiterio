<?php $__env->startSection('title', 'Editar Empresa'); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="bg-white shadow rounded-lg p-6">
        <h2 class="text-2xl font-bold text-gray-900 mb-6">Editar Empresa</h2>

        
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.empresa-form-edit', ['empresaId' => $empresa->id]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3250936740-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u566381090/domains/cemiterioonline.com/resources/views/admin/empresas/edit.blade.php ENDPATH**/ ?>