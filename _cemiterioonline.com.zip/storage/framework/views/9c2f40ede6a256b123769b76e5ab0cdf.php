<?php $__env->startSection('title', 'Empresas'); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="flex items-center justify-between mb-4">
        <h2 class="text-2xl font-bold text-gray-900">Empresas</h2>

        <a href="<?php echo e(route('admin.empresas.create')); ?>"
           class="inline-flex items-center px-4 py-2 bg-gray-800 text-white rounded-md hover:bg-gray-700 transition">
           Nova Empresa
        </a>
    </div>

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('admin.empresa-index');

$__html = app('livewire')->mount($__name, $__params, 'lw-1591687129-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u566381090/domains/cemiterioonline.com/resources/views/admin/empresas/index.blade.php ENDPATH**/ ?>